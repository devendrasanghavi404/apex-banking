package com.apexbank.apexbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApexBankMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApexBankMainApplication.class, args);
	}

}
